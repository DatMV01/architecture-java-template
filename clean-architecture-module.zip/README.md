<h1> architecture-java-template </h1>
<h2> clean-architecture-module </h2>

![clean-architecture-module.png](clean-architecture-module.png)