<h1> architecture-java-template </h1>
<h2> hexagonal-architecture-module </h2>

![hexagonal-architecture-module.png](hexagonal-architecture-module.png)