package com.example.architecture.adapter;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AppTest {
    @Test
    void addition() {
        assertEquals(2, 2);
    }
}
